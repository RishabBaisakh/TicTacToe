import React from "react";

function Header() {
  return (
    <div>
      <h3 className="text-center mb-4">Tic Tac Toe</h3>
      <hr />
    </div>
  );
}

export default Header;
