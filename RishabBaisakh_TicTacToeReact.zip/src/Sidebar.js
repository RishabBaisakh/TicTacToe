import React from "react";

function Sidebar() {
  return (
    <div>
      <h2>Sidebar</h2>
    </div>
  );
}

export default Sidebar;
